import React, { Fragment } from "react";

const NotFound = () => (
  <Fragment>
    <h1>404 No Encontrado</h1>
  </Fragment>
);

export default NotFound;
