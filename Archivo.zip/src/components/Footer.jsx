import React from "react";
import "../styles/components/Footer.scss"

const Footer = () => (
  <div>
    <footer>Soy el Footer</footer>
  </div>
);

export default Footer;
