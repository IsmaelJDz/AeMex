import { combineReducers } from "redux";
import search from "./searchData";

const rootReducer = combineReducers({
  search,
});

export default rootReducer;