export const GET_DATA_TRAVELS = "GET_DATA_TRAVELS"
export const LOADING = "LOADING"
export const ERROR = "ERROR"