export const validarFormularioAction = estado => {
  return {
    type: 'VALIDAR_FORMULARIO',
    payload: estado
  }
}