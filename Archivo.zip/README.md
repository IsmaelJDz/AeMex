This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

before to write npm start you must to install npm packages

### `technolgies`

*react
*react-router -> routes
*axios -> get data API
*redux -> adming global state
\*redux-saga -> admin global state with async actions

### `npm install`

In the project directory, you can run:

### `yarn start or npm start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
